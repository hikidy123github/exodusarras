# Update (04/11/2022): If there are ten people, how many corpses will there be?
- Added Elite Battleship
- Added Nest Keeper
- Fixed the ratio scaling
- Optimizations
- Changed the gamemode to FFA

# Update (04/06/2022): Well hello there
- Added Elite Battleship
- Added Nest Keeper
- Fixed the ratio scaling
- Optimizations
- Changed the gamemode to FFA

# Update (04/05/2022): Well hello there
- Rewrote the crasher spawning system
- Rewrote the food spawning system
- Changed the color of the purple team's base

# Update (04/04/2022): I should write down my changes
- Fixed issues with the client's HTML code
- Added a way to recover your tank if you disconnect
- Added an option in the options menu to make health bars the color of the entity they are bound to
- You can now hold down M to max a stat
- Rewrote boss spawning

# Update (04/03/2022): How is this running so fast on glitch wtf
- Added most tanks back to the game
- Basic balancing
- Implemented a fix for ratio scalling

# Update (04/02/2022): Wow I'm actually making progress
- Split up the client files
- Optimized rendering processes
- Improved some stuff serverside

# Update (04/01/2022): This isn't an April Fool's Joke
- This template was initiated, and is being made to be a more complete, optimized and better
- This will have gamemodes, tanks and easier to use and modify files